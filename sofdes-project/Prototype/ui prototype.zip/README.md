# Campus Lost and Found System Prototype

Clickable frontend proof-of-concept for a campus lost-and-found system.

Version: v0.1.0

## Run locally

```bash
npm install
npm run dev
```

For a Radmin VPN or same-network demo:

```bash
npm run dev:lan
```

## Scope

- React + Vite + Tailwind CSS
- React Router navigation
- Mock data only
- No authentication
- No backend, API, SQL, or database

The prototype is intended for planning and presentation before production implementation.
