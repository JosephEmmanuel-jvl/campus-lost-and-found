# Campus Lost and Found System Prototype v0.1.0

Saved release: v0.1.0

## Included Screens

- Login
- Student Dashboard
- Report Lost Item
- Report Found Item
- Browse Found Items
- Lost Report Details
- Notifications
- Claim Request
- Admin Dashboard
- Admin Report Review

## Included Behaviors

- React Router navigation across all prototype pages
- Mock campus reports, found items, notifications, claims, and admin queue data
- Student-facing lost item and claim request flows
- Admin-facing review and report verification flows
- Responsive Tailwind CSS layout
- LAN demo command for Radmin VPN or same-network sharing
- Vercel and Netlify routing configuration

## Prototype Scope

- Frontend only
- Mock JSON-style data only
- No authentication
- No backend
- No API
- No SQL or database
- No persistent form submission

This release is intended for planning, presentation, and stakeholder review before production development.
