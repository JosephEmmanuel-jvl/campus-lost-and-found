import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import AppShell from './App.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';
import AdminReportReview from './pages/AdminReportReview.jsx';
import BrowseFoundItems from './pages/BrowseFoundItems.jsx';
import ClaimRequest from './pages/ClaimRequest.jsx';
import Login from './pages/Login.jsx';
import LostReportDetails from './pages/LostReportDetails.jsx';
import Notifications from './pages/Notifications.jsx';
import ReportFoundItem from './pages/ReportFoundItem.jsx';
import ReportLostItem from './pages/ReportLostItem.jsx';
import StudentDashboard from './pages/StudentDashboard.jsx';
import './index.css';

function Root() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route element={<AppShell />}>
          <Route path="/dashboard" element={<StudentDashboard />} />
          <Route path="/report-lost" element={<ReportLostItem />} />
          <Route path="/report-found" element={<ReportFoundItem />} />
          <Route path="/found-items" element={<BrowseFoundItems />} />
          <Route path="/lost-reports/:id" element={<LostReportDetails />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/claim-request" element={<ClaimRequest />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/review/:id" element={<AdminReportReview />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Root />);
