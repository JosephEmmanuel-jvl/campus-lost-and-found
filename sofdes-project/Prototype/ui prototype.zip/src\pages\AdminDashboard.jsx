import { Link } from 'react-router-dom';
import { ClipboardList, PackageCheck, ShieldCheck, UsersRound } from 'lucide-react';
import { adminQueue, claimRequests, foundItems, offices } from '../data/mockData';
import { OfficeIcon, PageHeader, SectionCard, StatCard, StatusBadge } from '../components/ui';

export default function AdminDashboard() {
  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Admin workspace"
        title="Admin Dashboard"
        description="Review incoming reports, monitor campus holding offices, and process claim requests."
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Review queue" value={adminQueue.length} icon={ClipboardList} tone="rose" detail="Reports and claims" />
        <StatCard label="Items in custody" value={foundItems.filter((item) => item.status !== 'Returned').length} icon={PackageCheck} tone="green" detail="Across all offices" />
        <StatCard label="Pending claims" value={claimRequests.filter((claim) => claim.status === 'Pending Review').length} icon={UsersRound} tone="amber" detail="Awaiting verification" />
        <StatCard label="Returned this month" value="18" icon={ShieldCheck} tone="blue" detail="Mock June metric" />
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.25fr_0.75fr]">
        <SectionCard title="Reports Needing Review" subtitle="Admin queue with mocked routing and assignment">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-xs uppercase tracking-[0.12em] text-slate-500">
                  <th className="pb-3 font-semibold">Record</th>
                  <th className="pb-3 font-semibold">Type</th>
                  <th className="pb-3 font-semibold">Signal</th>
                  <th className="pb-3 font-semibold">Assigned</th>
                  <th className="pb-3 font-semibold">Status</th>
                  <th className="pb-3 font-semibold">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {adminQueue.map((item) => (
                  <tr key={item.id}>
                    <td className="py-4">
                      <p className="font-semibold text-campus-ink">{item.title}</p>
                      <p className="text-xs text-slate-500">{item.id} · {item.age}</p>
                    </td>
                    <td className="py-4 text-slate-600">{item.type}</td>
                    <td className="py-4 text-slate-600">{item.ownerSignal}</td>
                    <td className="py-4 text-slate-600">{item.assignedTo}</td>
                    <td className="py-4"><StatusBadge value={item.status} /></td>
                    <td className="py-4">
                      <Link to={`/admin/review/${item.id}`} className="font-semibold text-campus-green hover:text-teal-800">
                        Review
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>

        <SectionCard title="Holding Offices" subtitle="Campus locations with active custody">
          <div className="space-y-3">
            {offices.map(([office, count, location], index) => (
              <div key={office} className="flex items-center gap-3 rounded-md border border-slate-200 p-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-campus-mist">
                  <OfficeIcon index={index} />
                </div>
                <div>
                  <p className="font-semibold text-campus-ink">{office}</p>
                  <p className="text-sm text-slate-500">{count} · {location}</p>
                </div>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>

      <SectionCard title="Claim Requests" subtitle="Mock claim statuses for presentation">
        <div className="grid gap-4 md:grid-cols-2">
          {claimRequests.map((claim) => (
            <div key={claim.id} className="rounded-lg border border-slate-200 p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-semibold text-campus-ink">{claim.item}</p>
                  <p className="mt-1 text-sm text-slate-500">{claim.id} · {claim.submitted}</p>
                </div>
                <StatusBadge value={claim.status} />
              </div>
              <p className="mt-3 text-sm text-slate-600">{claim.student} · {claim.office}</p>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}
