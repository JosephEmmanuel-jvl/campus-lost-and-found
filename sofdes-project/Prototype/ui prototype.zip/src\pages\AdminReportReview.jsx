import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, CheckCircle2, XCircle } from 'lucide-react';
import { adminQueue, foundItems, lostReports } from '../data/mockData';
import { AlertStrip, ItemThumbnail, MiniTimeline, PageHeader, ReviewChecklist, SectionCard, StatusBadge } from '../components/ui';

export default function AdminReportReview() {
  const { id } = useParams();
  const queueItem = adminQueue.find((item) => item.id === id) || adminQueue[0];
  const foundItem = foundItems.find((item) => item.id === queueItem.relatedFoundId) || foundItems[0];
  const matchedReport = lostReports.find((report) => report.id === queueItem.relatedLostId) || lostReports[0];

  return (
    <div className="space-y-6">
      <Link to="/admin" className="inline-flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-campus-green">
        <ArrowLeft className="h-4 w-4" />
        Back to admin dashboard
      </Link>

      <PageHeader
        eyebrow={queueItem.id}
        title="Admin Report Review"
        description={`${queueItem.title} · ${queueItem.ownerSignal}`}
        action={<StatusBadge value={queueItem.status} />}
      />

      <AlertStrip>
        Private identifying details are shown in the admin review surface for ownership verification and are not exposed in public browsing.
      </AlertStrip>

      <div className="grid gap-6 xl:grid-cols-[420px_1fr]">
        <div className="space-y-6">
          <SectionCard title="Found item intake">
            <ItemThumbnail type={foundItem.thumbnail} />
            <dl className="mt-5 grid gap-3 text-sm">
              {[
                ['Item', foundItem.title],
                ['Found date', foundItem.foundDate],
                ['Location', foundItem.location],
                ['Holding office', foundItem.intakeOffice],
                ['Finder', foundItem.finder],
                ['Condition', foundItem.condition],
              ].map(([label, value]) => (
                <div key={label} className="flex justify-between gap-4 rounded-md bg-slate-50 p-3">
                  <dt className="font-semibold text-slate-700">{label}</dt>
                  <dd className="text-right text-slate-600">{value}</dd>
                </div>
              ))}
            </dl>
          </SectionCard>

          <SectionCard title="Review actions">
            <div className="grid gap-3">
              <button className="inline-flex items-center justify-center gap-2 rounded-md bg-campus-green px-4 py-2.5 text-sm font-semibold text-white hover:bg-teal-800">
                <CheckCircle2 className="h-4 w-4" />
                Approve match
              </button>
              <button className="inline-flex items-center justify-center gap-2 rounded-md border border-rose-200 bg-white px-4 py-2.5 text-sm font-semibold text-rose-700 hover:bg-rose-50">
                <XCircle className="h-4 w-4" />
                Reject claim
              </button>
              <Link to="/notifications" className="rounded-md border border-slate-300 px-4 py-2.5 text-center text-sm font-semibold text-slate-700 hover:bg-slate-50">
                Send notification
              </Link>
            </div>
          </SectionCard>
        </div>

        <div className="space-y-6">
          <SectionCard title="Matched lost report" subtitle="Student-submitted report connected to this found item">
            <div className="grid gap-4 md:grid-cols-2">
              {[
                ['Lost report', matchedReport.id],
                ['Owner', matchedReport.owner],
                ['Reported', matchedReport.reportedDate],
                ['Last seen', matchedReport.location],
                ['Category', matchedReport.category],
                ['Priority', matchedReport.priority],
              ].map(([label, value]) => (
                <div key={label} className="rounded-md bg-slate-50 p-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.12em] text-slate-500">{label}</p>
                  <p className="mt-1 text-sm font-medium text-campus-ink">{value}</p>
                </div>
              ))}
            </div>
            <p className="mt-5 rounded-md border border-slate-200 p-4 text-sm leading-6 text-slate-600">
              {matchedReport.description}
            </p>
          </SectionCard>

          <SectionCard title="Verification checklist">
            <ReviewChecklist />
          </SectionCard>

          <SectionCard title="Review timeline">
            <MiniTimeline
              events={[
                ['June 28, 2026 · 8:14 AM', 'Found item intake submitted'],
                ['June 28, 2026 · 9:18 AM', 'Possible match generated'],
                ['June 28, 2026 · 10:02 AM', 'Claim request assigned to admin'],
              ]}
            />
          </SectionCard>
        </div>
      </div>
    </div>
  );
}
