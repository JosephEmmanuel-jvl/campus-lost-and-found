import { Link } from 'react-router-dom';
import { Filter, Search } from 'lucide-react';
import { foundItems } from '../data/mockData';
import { ItemThumbnail, PageHeader, PrimaryLink, SectionCard, StatusBadge, inputClasses } from '../components/ui';

export default function BrowseFoundItems() {
  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Found catalog"
        title="Browse Found Items"
        description="Review items posted by campus offices and begin a claim request when an item looks familiar."
        action={<PrimaryLink to="/report-found">Report found item</PrimaryLink>}
      />

      <SectionCard title="Search found items">
        <div className="grid gap-3 md:grid-cols-[1fr_180px_160px]">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-slate-400" />
            <input className={`${inputClasses} pl-9`} defaultValue="laptop, bottle, ID, ring" />
          </div>
          <select className={inputClasses} defaultValue="All categories">
            <option>All categories</option>
            <option>Electronics</option>
            <option>Personal Item</option>
            <option>Jewelry</option>
            <option>School ID</option>
          </select>
          <button className="inline-flex items-center justify-center gap-2 rounded-md border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">
            <Filter className="h-4 w-4" />
            Filters
          </button>
        </div>
      </SectionCard>

      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {foundItems.map((item) => (
          <article key={item.id} className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
            <ItemThumbnail type={item.thumbnail} className="rounded-none" />
            <div className="space-y-4 p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-bold text-campus-ink">{item.title}</p>
                  <p className="mt-1 text-sm text-slate-500">{item.id} · {item.category}</p>
                </div>
                <StatusBadge value={item.status} />
              </div>
              <p className="text-sm leading-6 text-slate-600">{item.description}</p>
              <div className="grid gap-2 text-sm text-slate-500">
                <p><span className="font-semibold text-slate-700">Found:</span> {item.foundDate}</p>
                <p><span className="font-semibold text-slate-700">Location:</span> {item.location}</p>
                <p><span className="font-semibold text-slate-700">Held at:</span> {item.intakeOffice}</p>
              </div>
              <div className="flex flex-wrap gap-2 border-t border-slate-200 pt-4">
                {item.matchedLostReportId ? (
                  <Link to={`/lost-reports/${item.matchedLostReportId}`} className="rounded-md border border-slate-300 px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">
                    View match
                  </Link>
                ) : null}
                <Link to="/claim-request" className="rounded-md bg-campus-green px-3 py-2 text-sm font-semibold text-white hover:bg-teal-800">
                  Start claim
                </Link>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
